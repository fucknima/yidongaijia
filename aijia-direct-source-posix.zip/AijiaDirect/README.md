# 爱家直连（iOS 第三方客户端）

这是一个第三方 iOS 客户端，不是中国移动、移动爱家或其关联公司的官方应用或 SDK，也不代表上述任何一方。客户端由手机直接访问移动爱家当前使用的云端接口，获取实时或历史回放地址，再使用 MobileVLCKit 在本机解码；不需要经过自建服务器。

请只在你有权使用的账号和摄像头上运行。移动爱家接口、签名规则和服务策略可能变化，云端变更后客户端可能需要同步修改。本项目不提供或绕过官方授权，也不保证接口长期稳定。

## 当前功能

- 手机号和密码登录（短信验证码登录已移除）
- 自动读取账号下的摄像头列表，可选填 `mac_id` 或摄像头名称
- 获取实时地址并在本机播放 MPEG-TS/H.265/AAC
- 云台上下左右控制
- 按日期查询内存卡录像并在本机回放
- 保活、前后台刷新和断线重连
- 诊断日志导出；日志会脱敏手机号、密码、令牌、Cookie、签名和 URL 查询参数
- 可选将手机号、密码和摄像头选择保存到 iOS 钥匙串并自动连接

## 在 Mac 上构建

解压本目录后，在 Mac 上执行：

```bash
cd AijiaDirect
pod install
open AijiaDirect.xcworkspace
```

在 Xcode 中选择真实设备，为 Target 设置自己的 Apple Developer Team，然后运行。首次启动后，在 App 内输入移动爱家账号和密码。

如果 Bundle Identifier 已被占用，请把 `com.example.AijiaDirect` 改成自己的唯一标识。

## 没有 Mac：使用 GitHub Actions

仓库根目录的 `.github/workflows/build-ios.yml` 会在 macOS runner 上安装 CocoaPods、编译设备版本并上传 `AijiaDirect-unsigned-ipa`。该 IPA 未签名，需要用自己的 Apple ID 或开发者证书重新签名后安装。免费 Apple ID 的侧载有效期和设备数量受 Apple 限制。

## 依赖和限制

- 需要 macOS、Xcode 和 CocoaPods；播放器依赖 [MobileVLCKit 3.4.0](https://github.com/videolan/vlckit)。
- 移动爱家云端接口不是公开稳定 SDK，接口、签名或服务策略变化后需要调整客户端。
- 密码只在用户选择记住登录时写入 iOS 钥匙串；诊断日志不记录完整凭据或令牌。
- 发布到 App Store 前，请自行检查 Apple、MobileVLCKit 和相关接口的许可及再分发要求。

## 主要文件

- `AijiaDirect/Services/AijiaAPI.swift`：云端登录、摄像头列表、设备令牌、实时/历史地址和保活。
- `AijiaDirect/Services/PlayerViewModel.swift`：登录持久化、播放/回放状态、重连和定时器。
- `AijiaDirect/Services/DiagnosticsLogger.swift`：脱敏诊断日志和导出。
- `AijiaDirect/Services/CredentialStore.swift`：钥匙串凭据存取。
- `AijiaDirect/Views/VLCPlayerView.swift`：MobileVLCKit 的 SwiftUI 包装。

